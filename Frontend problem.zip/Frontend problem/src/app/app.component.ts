import { Bank } from "./entity/bank";
import { AppService } from "./app.service";
import { Component } from "@angular/core";
import { OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FormBuilder } from "@angular/forms";
import { Validators } from "@angular/forms";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  title = "BankAPI";
  bank: Bank[];
  filteredBank: Bank[];
  searchform : FormGroup;

  constructor(private service: AppService, private fb : FormBuilder) {}

  ngOnInit() {
    this.service.getBanksByCity("MUMBAI").subscribe(data => {
      this.bank = data;
      this.filteredBank = data;
    });
    

    this.searchform=this.fb.group(
      {
        searchbox : ["", Validators.required]
      }
    )
  }

  onSearch() {
    let searchedElement = this.searchform.get('searchbox').value;
    searchedElement.toUpperCase();
    if (searchedElement != null) {
      this.filteredBank = [];
      for (let bank of this.bank) {
        if (bank.bank_name.indexOf(searchedElement) >= 0) {
          this.filteredBank.push(bank);
        }
      }
    }
  }

  onCityChange() {
    (<HTMLInputElement>document.getElementById("searchValue")).value = ""
    let city = (<HTMLInputElement>document.getElementById("city")).value;
    this.service.getBanksByCity(city).subscribe(data => {
      this.bank = data;
      this.filteredBank = data;
    });
  }
}
