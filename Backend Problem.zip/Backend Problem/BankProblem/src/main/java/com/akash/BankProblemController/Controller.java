package com.akash.BankProblemController;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.akash.exception.BankProblemException;
import com.akash.service.BankService;
import com.akash.service.BranchService;

@RestController
@CrossOrigin("*")
public class Controller {
	
	@Autowired
	BankService bankService;
	
	@Autowired
	BranchService branchService;
	
	@GetMapping(value="/getbranch/ifsc/{ifsc}", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getBranchByIfsc(@PathVariable String ifsc)
	{
		Map<String, Object> result = new HashMap<>();
		try {
			result.put("message", "Branch with IFSC: "+ifsc);
			result.put("body", branchService.findBranchByIfscCode(ifsc));
			result.put("error", false);
			result.put("status", String.valueOf(HttpStatus.OK));
			return new ResponseEntity<Map<String, Object>>(result, HttpStatus.OK);
		}
		catch (BankProblemException e) {
			result.put("message", e.getMessage());
			result.put("body", null);
			result.put("error", true);
			result.put("status", String.valueOf(HttpStatus.EXPECTATION_FAILED));
			return new ResponseEntity<Map<String, Object>>(result, HttpStatus.OK);			 
		}	
		
	}
	
	
	@GetMapping(value="/getbranches/{bankName}/{bankCity}", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getBranchByIfsc(@PathVariable("bankName") String bankName, @PathVariable("bankCity") String bankCity)
	{
		
		Map<String, Object> result = new HashMap<>();
		try {
			result.put("message", "Fetched branches");
			result.put("body", branchService.findBranchesByBankNameAndCity(bankName, bankCity));
			result.put("error", false);
			result.put("status", String.valueOf(HttpStatus.OK));
			return new ResponseEntity<Map<String, Object>>(result, HttpStatus.OK);
		}
		catch (BankProblemException e) {
			result.put("message", e.getMessage());
			result.put("body", null);
			result.put("error", true);
			result.put("status", String.valueOf(HttpStatus.EXPECTATION_FAILED));
			return new ResponseEntity<Map<String, Object>>(result, HttpStatus.OK);			 
		}
		
	}
	
	

}
