package com.akash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akash.entity.Branch;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Integer> {
	
	public Branch findByIfsc(String ifsc);

	@Query(value="select * from branches b where b.bank_id=?1 AND b.city=?2",nativeQuery=true)
	public List<Branch> findByBankIdAndCity(int bankId, String city);
}
