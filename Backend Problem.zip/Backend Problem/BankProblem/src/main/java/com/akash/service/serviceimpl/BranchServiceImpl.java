package com.akash.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akash.entity.Bank;
import com.akash.entity.Branch;
import com.akash.exception.BankDaoException;
import com.akash.exception.NoBankFoundException;
import com.akash.exception.NoBranchFoundException;
import com.akash.repository.BankRepository;
import com.akash.repository.BranchRepository;
import com.akash.service.BranchService;

@Service
public class BranchServiceImpl implements BranchService {

	@Autowired
	private BankRepository bankRepo;

	@Autowired
	private BranchRepository branchRepo;

	@Override
	public List<Branch> findBranchesByBankNameAndCity(String bankName, String city)
			throws NoBranchFoundException, NoBankFoundException, BankDaoException {

		try {
			Bank b = bankRepo.findByBankName(bankName);
			if (b == null) {
				throw new NoBankFoundException("Unable to find a bank with this name");
			}

			List<Branch> branches = branchRepo.findByBankIdAndCity(b.getBankId(), city);

			if (branches.size() == 0) {
				throw new NoBranchFoundException("No branches found for this bank");
			}

			return branches;
		} catch (RuntimeException e) {
			throw new BankDaoException("Unable to connect to database, please try again later");
		}

	}

	public Branch findBranchByIfscCode(String ifsc) throws NoBranchFoundException, BankDaoException {

		try {

			Branch branch = branchRepo.findByIfsc(ifsc);
			if (branch == null) {
				throw new NoBranchFoundException("No bank found with this IFSC code. Please check your input");
			}

			return branch;
		} catch (RuntimeException e) {
			throw new BankDaoException("Unable to connect to database, please try again later");
		}

	}

}
