package com.akash.service;

import java.util.List;

import com.akash.entity.Branch;
import com.akash.exception.BankDaoException;
import com.akash.exception.NoBankFoundException;
import com.akash.exception.NoBranchFoundException;

public interface BranchService {

	
	public List<Branch> findBranchesByBankNameAndCity(String bankName, String city) throws NoBranchFoundException, NoBankFoundException,  BankDaoException;
	public Branch findBranchByIfscCode(String ifsc) throws NoBranchFoundException, BankDaoException;
	
	
	
}
