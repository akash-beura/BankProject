package com.akash.service.serviceimpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.akash.repository.BankRepository;
import com.akash.repository.BranchRepository;
import com.akash.service.BankService;

@Service
public class BankServiceImpl implements BankService {

	@Autowired
	BankRepository bankRepo;
	
	@Autowired
	BranchRepository branchRepo;
	
	
	

}
