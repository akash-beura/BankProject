package com.akash.exception;

public class BankDaoException extends RuntimeException{

	public BankDaoException(String msg) {
	
		super(msg);
		
	}
}
