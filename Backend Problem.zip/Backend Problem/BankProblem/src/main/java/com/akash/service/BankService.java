package com.akash.service;

import com.akash.entity.Bank;
import com.akash.exception.NoBankFoundException;

public interface BankService {
	
	

}
