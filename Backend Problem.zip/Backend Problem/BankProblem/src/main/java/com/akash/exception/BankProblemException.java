package com.akash.exception;

public class BankProblemException extends RuntimeException {
	
	public BankProblemException(String msg) {
		super(msg);
	}

}
