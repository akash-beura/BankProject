package com.akash.exception;

public class NoBranchFoundException extends BankProblemException {

	public NoBranchFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
