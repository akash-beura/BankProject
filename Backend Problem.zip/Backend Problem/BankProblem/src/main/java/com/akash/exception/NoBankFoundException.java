package com.akash.exception;

public class NoBankFoundException extends BankProblemException {

	public NoBankFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
